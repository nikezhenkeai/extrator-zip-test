/**
 * 示例脚本文件
 * 包含一些有用的函数
 */

// 计算阶乘
function factorial(n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

// 生成斐波那契数列
function fibonacci(length) {
    const sequence = [0, 1];
    for (let i = 2; i < length; i++) {
        sequence[i] = sequence[i - 1] + sequence[i - 2];
    }
    return sequence.slice(0, length);
}

// 格式化日期
function formatDate(date, separator = '-') {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return [year, month, day].join(separator);
}
const ab1m = new ArrayBuffer(1048576);
console.log('示例脚本加载完成',ab1m);